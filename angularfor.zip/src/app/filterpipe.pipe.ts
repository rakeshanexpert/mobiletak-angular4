import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterpipePipe implements PipeTransform {

  transform(serviceJsonData: any, filterSearch: any): any {
    if(!filterSearch) return serviceJsonData;
      return serviceJsonData.filter(function(listSec:any){
        console.log(listSec);
        return listSec.snippet.title.toLowerCase().includes(filterSearch.toLowerCase())
     
      })
  }

}